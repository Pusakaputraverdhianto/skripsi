<!doctype html>
<html class="no-js" lang="">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Dashboard One | Notika - Notika Admin Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
		============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,900" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="{{ URL::asset('css/bootstrap.min.css') }}">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="{{ URL::asset('css/font-awesome.min.css') }}">
    <!-- owl.carousel CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/owl.carousel.css')}}">
    <link rel="stylesheet" href="{{URL::asset('css/owl.theme.css')}}">
    <link rel="stylesheet" href="{{URL::asset('css/owl.transitions.css')}}">
    <!-- meanmenu CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/meanmenu/meanmenu.min.css')}}">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/animate.css')}}">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/normalize.css')}}">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/scrollbar/jquery.mCustomScrollbar.min.css')}}">
    <!-- jvectormap CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/jvectormap/jquery-jvectormap-2.0.3.css')}}">
    <!-- notika icon CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/notika-custom-icon.css')}}">
    <link rel="stylesheet" href="{{URL::asset('css/jquery.dataTables.min.css')}}">

    <link rel="stylesheet" href="{{URL::asset('css/chosen/chosen.css')}}">
    <!-- notification CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/notification/notification.css')}}">
    <!-- dropzone CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/dropzone/dropzone.css')}}">
    <!-- wave CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/wave/waves.min.css')}}">
    <!-- main CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/main.css')}}">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('style.css')}}">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/responsive.css')}}">

    <link rel="stylesheet" href="{{URL::asset('css/bootstrap-select/bootstrap-select.css')}}">
    <!-- datapicker CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/datapicker/datepicker3.css')}}">
    <!-- Color Picker CSS
		============================================ -->
    <link rel="stylesheet" href="{{URL::asset('css/color-picker/farbtastic.css')}}">
    <!-- modernizr JS
		============================================ -->
    <script src="{{URL::asset('js/vendor/modernizr-2.8.3.min.js')}}"></script>
    <style>
      #not_avail {
        background-color: #fbcfcf;
      }
    </style>
</head>

{{-- Set global variable for url --}}
<script>
    var globalUri='{{ url('/') }}';
</script>

<body>

    @include('partials.navbar')
    @include('partials.menu')
    @yield('content')


    {{-- <div class="footer-copyright-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="footer-copy-right">
                        <p>Copyright © 2018. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
                    </div>
                </div>
            </div>
        </div>
    </div> --}}

    <script src="{{URL::asset('js/vendor/jquery-1.12.4.min.js')}}"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="{{URL::asset('js/bootstrap.min.js')}}"></script>
    <!-- wow JS
		============================================ -->
    <script src="{{URL::asset('js/wow.min.js')}}"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="{{URL::asset('js/jquery-price-slider.js')}}"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="{{URL::asset('js/owl.carousel.min.js')}}"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="{{URL::asset('js/jquery.scrollUp.min.js')}}"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="{{URL::asset('js/meanmenu/jquery.meanmenu.js')}}"></script>
    <!-- counterup JS
		============================================ -->
    <script src="{{URL::asset('js/counterup/jquery.counterup.min.js')}}"></script>
    <script src="{{URL::asset('js/counterup/waypoints.min.js')}}"></script>
    <script src="{{URL::asset('js/counterup/counterup-active.js')}}"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="{{URL::asset('js/scrollbar/jquery.mCustomScrollbar.concat.min.js')}}"></script>
    <!-- jvectormap JS
		============================================ -->
    <script src="{{URL::asset('js/sparkline/jquery.sparkline.min.js')}}"></script>
    <script src="{{URL::asset('js/sparkline/sparkline-active.js')}}"></script>
    <!-- sparkline JS
		============================================ -->
    <script src="{{URL::asset('js/flot/jquery.flot.js')}}"></script>
    <script src="{{URL::asset('js/flot/jquery.flot.resize.js')}}"></script>
    <script src="{{URL::asset('js/flot/curvedLines.js')}}"></script>
    <script src="{{URL::asset('js/flot/flot-active.js')}}"></script>
    <!-- knob JS
		============================================ -->
    <script src="{{URL::asset('js/knob/jquery.knob.js')}}"></script>
    <script src="{{URL::asset('js/knob/jquery.appear.js')}}"></script>
    <script src="{{URL::asset('js/knob/knob-active.js')}}"></script>
    <!--  wave JS
		============================================ -->
    <script src="{{URL::asset('js/wave/waves.min.js')}}"></script>
    <script src="{{URL::asset('js/wave/wave-active.js')}}"></script>
    <!--  todo JS
		============================================ -->
    <script src="{{URL::asset('js/todo/jquery.todo.js')}}"></script>
    <!-- plugins JS
		============================================ -->
    <script src="{{URL::asset('js/plugins.js')}}"></script>
	<!--  Chat JS
		============================================ -->
    <script src="{{URL::asset('js/chat/moment.min.js')}}"></script>

       <!-- Data Table JS
    ============================================ -->
    <script src="{{URL::asset('js/data-table/jquery.dataTables.min.js')}}"></script>
    <script src="{{URL::asset('js/data-table/data-table-act.js')}}"></script>

    <script src="{{URL::asset('js/icheck/icheck.min.js')}}"></script>
    <script src="{{URL::asset('js/icheck/icheck-active.js')}}"></script>

    <script src="{{URL::asset('js/knob/jquery.knob.js')}}"></script>
    <script src="{{URL::asset('js/knob/jquery.appear.js')}}"></script>
    <script src="{{URL::asset('js/knob/knob-active.js')}}"></script>
    <!-- Input Mask JS
		============================================ -->
    <script src="{{URL::asset('js/jasny-bootstrap.min.js')}}"></script>
    <!-- icheck JS
		============================================ -->
    <script src="{{URL::asset('js/icheck/icheck.min.js')}}"></script>
    <script src="{{URL::asset('js/icheck/icheck-active.js')}}"></script>
    <!-- rangle-slider JS
		============================================ -->
    <script src="{{URL::asset('js/rangle-slider/jquery-ui-1.10.4.custom.min.js')}}"></script>
    <script src="{{URL::asset('js/rangle-slider/jquery-ui-touch-punch.min.js')}}"></script>
    <script src="{{URL::asset('js/rangle-slider/rangle-active.js')}}"></script>
    <!-- datapicker JS
		============================================ -->
    <script src="{{URL::asset('js/datapicker/bootstrap-datepicker.js')}}"></script>
    <script src="{{URL::asset('js/datapicker/datepicker-active.js')}}"></script>
    <!-- bootstrap select JS
		============================================ -->
    <script src="{{URL::asset('js/bootstrap-select/bootstrap-select.js')}}"></script>
    <!--  color-picker JS
		============================================ -->
    <script src="{{URL::asset('js/color-picker/farbtastic.min.js')}}"></script>
    <!--  notification JS
		============================================ -->
    <script src="{{URL::asset('js/notification/bootstrap-growl.min.js')}}"></script>
    <script src="{{URL::asset('js/notification/notification-active.js')}}"></script>
    <!--  summernote JS
		============================================ -->
    <script src="{{URL::asset('js/summernote/summernote-updated.min.js')}}"></script>
    <script src="{{URL::asset('js/summernote/summernote-active.js')}}"></script>
    <!-- dropzone JS
		============================================ -->
    <script src="{{URL::asset('js/dropzone/dropzone.js')}}"></script>
    <!--  chosen JS
		============================================ -->
    <script src="{{URL::asset('js/chosen/chosen.jquery.js')}}"></script>
    <!-- main JS
		============================================ -->
    <script src="{{URL::asset('js/main.js')}}"></script>
    <script src="//cdn.datatables.net/buttons/1.2.4/js/dataTables.buttons.min.js"></script>
<script src="//cdn.datatables.net/buttons/1.2.4/js/buttons.flash.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.print.min.js"></script>
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="https://cdn.datatables.net/select/1.3.0/js/dataTables.select.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>

    <script>

      
      </script>

    @yield('scripts')

</body>
</html>
