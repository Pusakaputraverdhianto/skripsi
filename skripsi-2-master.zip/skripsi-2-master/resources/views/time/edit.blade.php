@extends('main_layout')
@section('content')

<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcomb-list">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcomb-wp">
                                <div class="breadcomb-icon">
                                    <i class="notika-icon notika-support"></i>
                                </div>
                                <div class="breadcomb-ctn">
                                    <h2>Waktu Praktek</h2>
                                    <p>Edit data waktu praktek.</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@if(session('success') || session('error'))
<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                @if(session('success'))
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('success')}}
                </div>
                @endif

                @if(session('error'))
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('error')}}
                </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endif

<div class="form-element-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                {!! Form::model($time, ['route' => ['time.update', $time->time_id], 'method' => 'put']) !!}
                <div class="form-element-list mg-t-30">
                    <div class="cmp-tb-hd">
                        <h2>Form edit waktu praktek.</i></h2>
                        <p>Semua <i>field</i> wajib diisi.</p>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <select class="selectpicker" name="time_type" required>
                                    <option value="">Silahkan Pilih Sesi Praktek</option>
                                    <option value="pagi" {{($time->time_type == 'pagi')?'selected':''}}>Pagi (06.00-12.00)</option>
                                    <option value="siang" {{($time->time_type == 'siang')?'selected':''}}>Siang (13.00-18.00)</option>
                                    <option value="malam" {{($time->time_type == 'malam')?'selected':''}}>Malam (18.30-24)</option>
                                </select>
                                @if ($errors->has('time_type'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('time_type') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-social"></i>
                                </div>
                                <div class="nk-int-st">
                                    <input type="text" name="time_schedule" class="form-control time" placeholder="Waktu Praktek" value="{{ $time->time_schedule }}">
                                </div>
                                @if ($errors->has('time_schedule'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('time_schedule') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-clock"></i>
                                </div>
                                <div class="nk-int-st">
                                    <input type="text" name="limit_pasien" class="form-control time" placeholder="Jumlah Pasien" value="{{ $time->time_limit_pasien }}">
                                </div>
                                @if ($errors->has('limit_pasien'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('limit_pasien') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <a href="{{ URL::to('time/list/'.$time->doctor_id) }}" class="btn btn-danger notika-btn-danger"><i class="notika-icon notika-close"></i> Batal</a>
                            <button class="btn btn-success notika-btn-success"><i class="notika-icon notika-sent"></i> Simpan</button>
                        </div>
                    </div>
                </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>

@endsection