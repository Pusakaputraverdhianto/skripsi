@extends('main_layout')
@section('content')

<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcomb-list">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcomb-wp">
                                <div class="breadcomb-icon">
                                    <i class="notika-icon notika-support"></i>
                                </div>
                                <div class="breadcomb-ctn">
                                    <h2>Dokter</h2>
                                    <p>Menambahkan data dokter baru.</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@if(session('success') || session('error'))
<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                @if(session('success'))
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('success')}}
                </div>
                @endif

                @if(session('error'))
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('error')}}
                </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endif

<div class="form-element-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                {!! Form::open(['route' => 'doctor.store', 'method' => 'post', 'enctype' => 'multipart/form-data']) !!}
                <div class="form-element-list mg-t-30">
                    <div class="cmp-tb-hd">
                        <h2>Form penambahan data dokter.</i></h2>
                        <p>Semua <i>field</i> wajib diisi.</p>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-support"></i>
                                </div>
                                <div class="nk-int-st">
                                    <input type="text" name="doctor_name" class="form-control" placeholder="Nama Lengkap & Gelar" value="{{ old('doctor_name') }}">
                                </div>
                                @if ($errors->has('doctor_name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('doctor_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-social"></i>
                                </div>
                                <div class="nk-int-st">
                                    <input type="text" name="doctor_nik" class="form-control" placeholder="NIK" value="{{ old('doctor_nik') }}">
                                </div>
                                @if ($errors->has('doctor_nik'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('doctor_nik') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-star"></i>
                                </div>
                                <div class="nk-int-st">
                                    <input type="text" name="doctor_specialist" class="form-control" placeholder="Spesialist" value="{{ old('doctor_specialist') }}">
                                </div>
                                @if ($errors->has('doctor_specialist'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('doctor_specialist') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                    <select class="selectpicker" name="poli" required>
                                        <option value="">Silahkan Pilih Poliklinik</option>
                                        @foreach($poli as $item)
                                        <option value="{{ $item->poli_id }}">{{ $item->poli_name }}</option>
                                        @endforeach
                                    </select>
                                @if ($errors->has('poli'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('poli') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-phone"></i>
                                </div>
                                <div class="nk-int-st">
                                    <input type="text" name="doctor_phone" class="form-control" placeholder="No. Telp / HP" value="{{ old('doctor_phone') }}">
                                </div>
                                @if ($errors->has('doctor_phone'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('doctor_phone') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-mail"></i>
                                </div>
                                <div class="nk-int-st">
                                    <input type="text" name="doctor_email" class="form-control" placeholder="Email" value="{{ old('doctor_email') }}">
                                </div>
                                @if ($errors->has('doctor_email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('doctor_email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-ip-locator"></i>
                                </div>
                                <div class="nk-int-st">
                                    <textarea type="text" name="doctor_address" class="form-control" placeholder="Alamat" value="{{ old('doctor_address') }}">{{ old('doctor_address') }}</textarea>
                                </div>
                                @if ($errors->has('doctor_address'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('doctor_address') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-edit"></i>
                                </div>
                                <div class="nk-int-st">
                                    <textarea type="text" name="doctor_desc" class="form-control" placeholder="Deskripsi" value="{{ old('doctor_desc') }}">{{ old('doctor_desc') }}</textarea>
                                </div>
                                @if ($errors->has('doctor_desc'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('doctor_desc') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-picture"></i>
                                </div>
                                <div class="nk-int-st">
                                    <input type="file" name="image" class="form-control" placeholder="image" value="{{ old('image') }}">
                                </div>
                                @if ($errors->has('poli_desc'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('poli_desc') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <a href="{{ url('doctor') }}" class="btn btn-danger notika-btn-danger"><i class="notika-icon notika-close"></i> Batal</a>
                            <button class="btn btn-success notika-btn-success"><i class="notika-icon notika-sent"></i> Simpan</button>
                        </div>
                    </div>
                </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>

@endsection