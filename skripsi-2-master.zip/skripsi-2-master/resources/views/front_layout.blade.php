<!doctype html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="TRABBLE - Tour, Travel, Travel Agency Template">
    <meta name="keywords" content="Tour, Travel, Travel Agency Template">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabble- Tour, Travel & Travel Agency Template</title>
    <!-- Google Fonts Includes -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <!-- Favi icon -->
    <link rel="shortcut icon" type="image/x-icon" href="{{ URL::asset('asset/images/favicon.ico') }}">
    <!-- bootstrap v3.3.6 css -->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/bootstrap.min.css') }}">
    <!-- animate css -->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/animate.css') }}">
    <!-- Button Hover animate css -->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/hover-min.css') }}">
    <!-- jquery-ui.min css -->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/jquery-ui.min.css') }}">
    <!-- meanmenu css -->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/meanmenu.min.css') }}">
    <!-- owl.carousel css -->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/owl.carousel.min.css') }}">
    <!-- slick css -->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/slick.css') }}">
    <!-- chosen.min-->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/chosen.min.css') }}">
    <!-- customselect.min-->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/jquery-customselect.css') }}">
    <!-- select2.min-->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/select2.min.css') }}">
    <!-- font-awesome css -->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/font-awesome.min.css') }}">
    <!-- magnific Css -->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/magnific-popup.css') }}">
    <!-- Revolution Slider -->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/assets/revolution/layers.css') }}">
    <link rel="stylesheet" href="{{ URL::asset('asset/css/assets/revolution/navigation.css') }}">
    <link rel="stylesheet" href="{{ URL::asset('asset/css/assets/revolution/settings.css') }}">
    <link rel="stylesheet" href="{{ URL::asset('asset/css/style.css') }}">
    <!-- responsive css -->
    <link rel="stylesheet" href="{{ URL::asset('asset/css/responsive.css') }}">
    <!-- modernizr css -->
    <script src="{{ URL::asset('asset/js/vendor/modernizr-2.8.3.min.js') }}"></script>

    <style>
        
    </style>
</head>

    <div class="header-area-style-3">
        <!-- header-bottom area start here -->
        <div class="header-bottom-area header-bottom-3 header-bottom-area-2" id="stick-header">
            <div class="container">
                <div class="row">
                    <div class="col-md-2">
                        <div class="logo-area">
                        <a href="{{ url('search') }}"><img src="{{ URL::asset('asset/images/logo2.png') }}" alt="">
                            </a>
                        </div>
                    </div> <!-- logo area end here -->

                    <!-- main menu start here -->
                    <div class="col-md-8 col-sm-8 phone-resp">
                        <nav>
                            <ul class="main-menu text-right">
                                <li class="active"><a href="{{ url('search') }}">Beranda</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div class="col-md-2 col-sm-2">
                        <div class="book-online">
                            <a href="{{ url('search/reservation') }}">Cek Reservasi</a>
                        </div>
                    </div> <!-- main menu end here -->
                </div>
            </div>
        </div> <!-- header-bottom area end here -->
    </div> <!-- header area end here -->
    @yield('content')
    
<body> 

    <script src="{{ URL::asset('asset/js/vendor/jquery-3.2.0.min.js') }}"></script>
    <!-- bootstrap js -->
    <script src="{{ URL::asset('asset/js/bootstrap.min.js') }}"></script>
    <!-- owl.carousel js -->
    <script src="{{ URL::asset('asset/js/owl.carousel.min.js') }}"></script>
    <!-- slick js -->
    <script src="{{ URL::asset('asset/js/slick.min.js') }}"></script>
    <!-- meanmenu js -->
    <script src="{{ URL::asset('asset/js/jquery.meanmenu.min.js') }}"></script>
    <!-- jquery-ui js -->
    <script src="{{ URL::asset('asset/js/jquery-ui.min.js') }}"></script>
    <!-- wow js -->
    <script src="{{ URL::asset('asset/js/wow.min.js') }}"></script>
    <!-- counter js -->
    <script src="{{ URL::asset('asset/js/jquery.counterup.min.js') }}"></script>
    <!-- Countdown js -->
    <script src="{{ URL::asset('asset/js/jquery.countdown.min.js') }}"></script>
    <!-- waypoints js -->
    <script src="{{ URL::asset('asset/js/jquery.waypoints.min.js') }}"></script>
    <!-- Isotope js -->
    <script src="{{ URL::asset('asset/js/isotope.pkgd.min.js') }}"></script>
    <!-- magnific js -->
    <script src="{{ URL::asset('asset/js/jquery.magnific-popup.min.js') }}"></script>
    <!-- Image loaded js -->
    <script src="{{ URL::asset('asset/js/imagesloaded.pkgd.min.js') }}"></script>
    <!-- chossen js -->
    <script src="{{ URL::asset('asset/js/chosen.jquery.min.js') }}"></script>
    <script src="{{ URL::asset('asset/js/assets/revolution/jquery.themepunch.revolution.min.js') }}"></script>
    <script src="{{ URL::asset('asset/js/assets/revolution/jquery.themepunch.tools.min.js') }}"></script>
    <!-- Revolution Extensions -->
    <script src="{{ URL::asset('asset/js/assets/revolution/extensions/revolution.extension.actions.min.js') }}"></script>
    <script src="{{ URL::asset('asset/js/assets/revolution/extensions/revolution.extension.carousel.min.js') }}"></script>
    <script src="{{ URL::asset('asset/js/assets/revolution/extensions/revolution.extension.kenburn.min.js') }}"></script>
    <script src="{{ URL::asset('asset/js/assets/revolution/extensions/revolution.extension.layeranimation.min.js') }}"></script>
    <script src="{{ URL::asset('asset/js/assets/revolution/extensions/revolution.extension.migration.min.js') }}"></script>
    <script src="{{ URL::asset('asset/js/assets/revolution/extensions/revolution.extension.navigation.min.js') }}"></script>
    <script src="{{ URL::asset('asset/js/assets/revolution/extensions/revolution.extension.parallax.min.js') }}"></script>
    <script src="{{ URL::asset('asset/js/assets/revolution/extensions/revolution.extension.slideanims.min.js') }}"></script>
    <script src="{{ URL::asset('asset/js/assets/revolution/extensions/revolution.extension.video.min.js') }}"></script> 
    <script src="{{ URL::asset('asset/js/assets/revolution/revolution.js') }}"></script>       
    <!-- Jquery plugin -->
    <script src="{{ URL::asset('asset/js/plugins.js') }}"></script>
    <!-- select2 js plugin -->
    <script src="{{ URL::asset('asset/js/select2.min.js') }}"></script>    
    <script src="{{ URL::asset('asset/js/colors.js') }}"></script>
    <!-- Jquery plugin -->
    <script src="{{ URL::asset('asset/js/jquery-customselect.js') }}"></script>
    <!-- main js -->
    <script src="{{ URL::asset('asset/js/custom.js') }}"></script>

    @yield('script')
</body>
</html>
