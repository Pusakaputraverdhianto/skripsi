@extends('main_layout')
@section('content')
<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcomb-list">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcomb-wp">
                                <div class="breadcomb-icon">
                                    <i class="notika-icon notika-support"></i>
                                </div>
                                <div class="breadcomb-ctn">
                                    <h2>User</h2>
                                    <p>Mengelola data user.</span></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
                            <div class="breadcomb-report">
                                @if(FunctionsHelper::checkAction($menuId, 'create'))
                                <a href="{{ url('add-user') }}" data-toggle="tooltip" data-placement="left" title="Create new user" class="btn"><i class="notika-icon notika-plus-symbol"></i></a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcomb area End-->

<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                @if(session('success'))
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('success')}}
                </div>
                @endif

                @if(session('error'))
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('error')}}
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- Data Table area Start-->
<div class="data-table-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="data-table-list">
                    <div class="table-responsive">
                        <table id="data-table-basic" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Nama Lengkap</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>Role</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($users as $key => $user)
                                <tr>
                                    <td>{{$key+1}}</td>
                                    <td>{{ucfirst($user->name)}}</td>
                                    <td>{{$user->email}}</td>
                                    <td>{!! ($user->status == 1)?"<p style='color:green'>Aktif</p>":"<p style='color:red'>Tidak Aktif</p>" !!}</td>
                                    <td>{{ isset($user->role->roles_name) ? ucfirst($user->role->roles_name):"-"}}</td>
                                    <td>
                                        @if(FunctionsHelper::checkAction($menuId, 'edit'))
                                        <a href="{{ URL::to('user/edit/'.$user->id) }}" data-toggle="tooltip" data-placement="left" title="Edit" class="btn btn-warning"><i class="notika-icon notika-edit"></i></a>
                                        @endif
                                        @if(FunctionsHelper::checkAction($menuId, 'delete'))
                                        <button data-href="{{ URL::to('user/delete/'.$user->id) }}" data-placement="right" data-toggle="modal" data-target="#confirmationDelete" title="Delete" class="btn btn-danger" onclick="confirmationDelete(this)"><i class="notika-icon notika-trash"></i></button>
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="6"></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="confirmationDelete" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">
                <h2>Konfirmasi.</h2>
                <p>Apakah anda yakin ingin menghapus data ini ?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default agree-action" data-dismiss="modal">Yakin</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
    <script>
        function confirmationDelete(dom) {
            $(".agree-action").click(function () {
                window.location = dom.dataset.href;
            });
        }
    </script>
@endsection