@extends('main_layout')
@section('content')
<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcomb-list">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcomb-wp">
                                <div class="breadcomb-icon">
                                    <i class="notika-icon notika-support"></i>
                                </div>
                                <div class="breadcomb-ctn">
                                    <h2>User Level</h2>
                                    <p>Mengelola data <i>level user</i>.</span></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
                            <div class="breadcomb-report">
                                @if(FunctionsHelper::checkAction($menuId, 'create'))
                                <a href="{{ url('add-role') }}" data-toggle="tooltip" data-placement="left" title="Tambah data" class="btn"><i class="notika-icon notika-plus-symbol"></i></a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcomb area End-->

<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                @if(session('success'))
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('success')}}
                </div>
                @endif

                @if(session('error'))
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('error')}}
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- Data Table area Start-->
<div class="data-table-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="data-table-list">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>User Level</th>
                                    <th>Akses</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($roles as $key => $role)
                                <tr>
                                    <td>{{$key+1}}</td>
                                    <td>{{ucfirst($role->roles_name)}}</td>
                                    <td>
                                        <ul>
                                            @foreach($role->roleMenu as $menu)
                                                <li>- <a href="{{ ($menu->menu->parent_id == null)?'#':URL::to('role/action/'.base64_encode($role->roles_id.'|'.$menu->menu->menu_id)) }}">{{ $menu->menu->menu_name }}</a></li>
                                            @endforeach
                                        </ul>
                                    </td>
                                    <td>
                                        @if(FunctionsHelper::checkAction($menuId, 'edit'))
                                        <a href="{{ URL::to('role/edit/'.$role->roles_id) }}" data-toggle="tooltip" data-placement="left" title="Edit" class="btn btn-warning"><i class="notika-icon notika-edit"></i></a>
                                        @endif
                                        @if(FunctionsHelper::checkAction($menuId, 'delete'))
                                        <button data-href="{{ URL::to('role/delete/'.$role->roles_id) }}" data-placement="right" data-toggle="modal" data-target="#confirmationDelete" title="Delete" class="btn btn-danger" onclick="confirmationDelete(this)"><i class="notika-icon notika-trash"></i></button>
                                        @endif

                                        <a href="{{ URL::to('role/access/'.$role->roles_id) }}" data-toggle="tooltip" data-placement="right" title="Akes" class="btn btn-primary"><i class="notika-icon notika-eye"></i></a>
                                       
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="6"></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="confirmationDelete" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">
                <h2>Konfirmasi.</h2>
                <p>Apakah anda yakin ingin menghapus data ini ?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default agree-action" data-dismiss="modal">Yakin</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
    <script>
        function confirmationDelete(dom) {
            $(".agree-action").click(function () {
                window.location = dom.dataset.href;
            });
        }
    </script>
@endsection