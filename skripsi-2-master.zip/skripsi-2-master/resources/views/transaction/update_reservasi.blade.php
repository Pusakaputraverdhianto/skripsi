@extends('main_layout')
@section('content')

<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcomb-list">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcomb-wp">
                                <div class="breadcomb-icon">
                                    <i class="notika-icon notika-house"></i>
                                </div>
                                <div class="breadcomb-ctn">
                                    <h2>Poliklinik</h2>
                                    <p>Menambahkan data poliklinik baru.</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@if(session('success') || session('error'))
<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                @if(session('success'))
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('success')}}
                </div>
                @endif

                @if(session('error'))
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('error')}}
                </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endif

<div class="form-element-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                {!! Form::open(['route' => 'update_jadwal_reservasi.store', 'method' => 'post', 'enctype' => 'multipart/form-data']) !!}
                <div class="form-element-list mg-t-30">
                    <div class="cmp-tb-hd">
                        <h2>Form update jadwal konsultasi.</i></h2>
                        <p>Semua <i>field</i> wajib diisi.</p>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-support"></i>
                                </div>
                                <div class="nk-int-st">
                                    <select type="text" name="doctor" class="form-control">
                                        <option value="">Pilih Dokter</option>
                                        @foreach ($doctor as $item)
                                        <option value="{{ $item->doctor_id }}">{{ $item->doctor_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @if ($errors->has('doctor'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('doctor') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-star"></i>
                                </div>
                                <div class="nk-int-st">
                                    <select type="text" name="time_type" class="form-control">
                                        <option value="">Pilih Waktu</option>
                                        <option value="pagi">Pagi</option>
                                        <option value="siang">Siang</option>
                                        <option value="malam">Malam</option>
                                    </select>
                                </div>
                                @if ($errors->has('time_type'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('time_type') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-calendar"></i>
                                </div>
                                <div class="nk-int-st">
                                    <input type="date" name="consultation_date" class="form-control" placeholder="Tanggal Konsultasi" value="{{ old('consultation_date') }}">
                                </div>
                                @if ($errors->has('consultation_date'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('consultation_date') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <div class="form-group ic-cmp-int float-lb floating-lb">
                                <div class="form-ic-cmp">
                                    <i class="notika-icon notika-refresh"></i>
                                </div>
                                <div class="nk-int-st">
                                    <input type="time" name="new_time" class="form-control" placeholder="Jam Konsultasi Baru" value="{{ old('new_time') }}">
                                </div>
                                @if ($errors->has('new_time'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('new_time') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <a href="{{ url('poli') }}" class="btn btn-danger notika-btn-danger"><i class="notika-icon notika-close"></i> Batal</a>
                            <button class="btn btn-success notika-btn-success"><i class="notika-icon notika-sent"></i> Simpan</button>
                        </div>
                    </div>
                </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>

@endsection