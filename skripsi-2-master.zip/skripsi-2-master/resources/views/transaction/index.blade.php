@extends('main_layout')
@section('content')
<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcomb-list">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcomb-wp">
                                <div class="breadcomb-icon">
                                    <i class="notika-icon notika-house"></i>
                                </div>
                                <div class="breadcomb-ctn">
                                    <h2>Reservasi</h2>
                                    <p>Data Reservasi Pasien</span></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
                            <div class="breadcomb-report">
                                {{-- @if(FunctionsHelper::checkAction($menuId, 'create'))
                                <a href="{{ url('add-poli') }}" data-toggle="tooltip" data-placement="left" title="Tambah data" class="btn"><i class="notika-icon notika-plus-symbol"></i></a>
                                @endif --}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcomb area End-->

<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                @if(session('success'))
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('success')}}
                </div>
                @endif

                @if(session('error'))
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('error')}}
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- Data Table area Start-->
<div class="data-table-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="data-table-list">
                    <div class="table-responsive">
                        <table id="data-table-basic" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>No. Reservasi</th>
                                    <th>Nama Pasien</th>
                                    <th>Nama Dokter</th>
                                    <th>Tanggal Berobat</th>
                                    <th>Waktu</th>
                                    <th>No. Antrian</th>
                                    <th>Dokumen</th>
                                    <th>Tanggal Reservasi</th>
                                    <th>Status</th>
                                    <th>Persetujuan</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($transactions as $key => $item)
                                    <tr>
                                        <td>{{ $key+1 }}</td>
                                        <td>{{ $item->transaction_code }}</td>
                                        <td>{{ ucwords($item->pasien->pasien_name) }}</td>
                                        <td>{{ $item->doctor->doctor_name }}</td>
                                        <td>{{ $item->transaction_schedule_date }}</td>
                                        <td>{{ ucwords($item->transaction_time_type).' - '.$item->transaction_schedule_time }}</td>
                                        <td>{{ sprintf('%04d', $item->transaction_queue_number) }}</td>
                                        <td>
                                            <a href="{{ $item->transaction_document }}" target="_blank">Link Dokumen</a>
                                        </td>
                                        <td>{{ date('Y-m-d H.i', strtotime($item->created_at)) }}</td>
                                        <td>{{ $item->status->status_name }}</td>
                                        <td>
                                            <select name="transaction_status" onchange="persetujuan(this)" data-transactionId="{{$item->transaction_id}}">
                                                <option value="">Pilih Status</option>
                                                <option value="4">Disetujui</option>
                                                <option value="5">Ditolak</option>
                                            </select>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="6"></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="confirmationDelete" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">
                <h2>Konfirmasi.</h2>
                <p>Apakah anda yakin ingin menghapus data ini ?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default agree-action" data-dismiss="modal">Yakin</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
    <script>
        function confirmationDelete(dom) {
            $(".agree-action").click(function () {
                window.location = dom.dataset.href;
            });
        }

        function persetujuan(dom) {
            $.ajax({
                    url: '{{ URL::to("change/transaction/status") }}',
                    method:"POST",
                    data:{
                        transaction_id: dom.dataset.transactionid,
                        transaction_status: dom.value
                    },
                    success:function(response) {
                        console.log(response)
                        window.location.reload()
                    },
                    error:function(){
                        alert("error");
                    }
                });
        };
    </script>
@endsection