@extends('front_layout')
@section('content')

<section class="herounit-bg">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="version-3-search-style">
					<div class="search-area-title text-center">
						<h2 style="color: red;">Temukan</h2>
						<h3 style="color: red;">Dokter & buat janji sekarang juga.</h3>
					</div>
					<div class="tabbased-search-3">
						<!-- tab menu 3 start-->
						<div class="tab-menu-item-3">
							<ul class="tab-menu-3" role="tablist">
								<li role="presentation" class="active">
                                    <a href="#hotels" aria-controls="hotels" role="tab" data-toggle="tab"><img src="{{ URL::asset('asset/images/icon/hotel-1.png') }}" alt="">
									</a>
								</li>
							</ul>
						</div> <!-- tab menu 3  end -->

						<div class="tab-content-3">
							<div class="tab-content">
								<!-- hotels form -->
								<div role="tabpanel" class="tab-pane fade in active" id="hotels">
									<div class="hotels-form-3">
										{!! Form::open(['route' => 'do-search', 'method' => 'post']) !!}
											<div class="thm-tk-input-2-1 input-b">
												<select class="location-results form-control" name="poli_id" id="standard4">
                                                    <option value="">Silahkan pilih poli</option>
                                                    @foreach($poli as $item)
                                                        <option value="{{ $item->poli_id }}">{{ $item->poli_name }}</option>
                                                    @endforeach
												</select>
												@if(session('error'))
												<p style="color: red">
													{{session('error')}}
												</p>
												@endif
											</div>
											<button type="submit" class="search-btn-3 hvr-shutter-out-horizontal">Cari Sekarang</button>
										{!! Form::close() !!}
									</div>
								</div> 
							</div>
						</div> <!-- tab content 3 end -->
					</div>
				</div>
			</div>
		</div>
	</div>
</section> <!-- hero unit end here -->

<section class="section-paddings popular-packages">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="section-title text-center">
					<h2>Klinik</h2>
					<p>Berikut list klinik terbaik yang ada di rumah sakit kami.</p>
				</div>
			</div>
		</div>
		<!-- popular packages start-->
		<div class="row">
            <!-- single package start -->
            @foreach($poli as $item)
			<div class="col-sm-4 col-md-4">
				<div class="single-package">
					<div class="package-image">
                    <a href="#"><img src="{{ $item->poli_image }}" alt="">
						</a>
					</div>
					<div class="package-content">
						<h3>{{ ucwords($item->poli_name) }}</h3>
						{{-- <p>4Days, 5 Nights Start From <span>$500</span> --}}
						</p>
					</div>
					<div class="package-calto-action">
						<ul class="ct-action">
							<li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Temukan Dokter</a>
							</li>
							<li>
								{{-- <i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i> --}}
							</li>
						</ul>
					</div>
				</div>
            </div>
            @endforeach
		</div> <!-- popular packages end-->
	</div>
</section> <!-- popular packajge start end -->


@endsection