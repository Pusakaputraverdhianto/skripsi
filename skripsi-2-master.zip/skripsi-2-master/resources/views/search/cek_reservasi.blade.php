@extends('front_layout')
@section('content')
<section class="section-paddings single-package-area">
	<div class="container">
        {!! Form::open(['route' => 'transactionHistory', 'method' => 'post']) !!}
		<div class="row">
            <div class="col-md-12 col-sm-12">
				<aside>
					<div class="booking-form">
						<div class="booking-title">
							<h4>Cek Data Reservasi</h4>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="transaction_code" placeholder="Masukkan No. Pemesanan">
                            @if ($errors->has('transaction_code'))
                                <span style="color: red">
                                    <strong>{{ $errors->first('transaction_code') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <button type="submit" id="btn_check" class="booking-confirm hvr-shutter-out-horizontal btn_check"></i> Cek Sekarang</button>
                        </div>
					</div>
                </aside>
                
                <br>
                @if(session('error'))
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('error')}}
                </div>
                @endif
            </div>
        </div>
        {!! Form::close() !!}
	</div>
</section>
@endsection

@section('script')
@endsection