@extends('front_layout')
@section('content')
<section class="section-paddings single-package-area">
	<div class="container">
        {!! Form::open(['route' => 'reservation', 'method' => 'post', 'enctype' => 'multipart/form-data']) !!}
		<div class="row">
            <div class="col-md-8 col-sm-12">
				<aside>
					<div class="booking-form">
						<div class="booking-title">
							<h4>Data Pasien</h4>
                        </div>
                        <div class="form-group">
                            <input type="hidden" class="form-control" name="doctor_id" value="{{ $doctor->doctor_id }}">
                            <input type="hidden" class="form-control" name="time_id" value="{{ $time->time_id }}">
                            <input type="hidden" class="form-control" name="schedule_id" value="{{ $schedule->schedule_id }}">
                            <input type="hidden" class="form-control" name="date" value="{{ $date }}">
                        </div>
                        <div class="input-group" style="height: 43px">
                            <input style="height: 43px" type="email" class="form-control" name="pasien_email" placeholder="Email" value="{{ old('pasien_email') }}" id="pasien_email">
                            <span class="input-group-addon btn btn-success" onclick="checkDataPasein(this)">Cek Data</span>
                            @if ($errors->has('pasien_email'))
                                <span style="color: red">
                                    <strong>{{ $errors->first('pasien_email') }}</strong>
                                </span>
                            @endif
                        </div>
                        <br>
                        <div class="form-group">
                            <input type="number" class="form-control" name="no_rekam_medis" placeholder="No. rekam medis pasien" value="{{ old('no_rekam_medis') }}" id="no_rekam_medis">
                            @if ($errors->has('no_rekam_medis'))
                                <span style="color: red">
                                    <strong>{{ $errors->first('no_rekam_medis') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="pasien_name" placeholder="Nama lengkap pasien" value="{{ old('pasien_name') }}" id="pasien_name">
                            @if ($errors->has('pasien_name'))
                                <span style="color: red">
                                    <strong>{{ $errors->first('pasien_name') }}</strong>
                                </span>
                            @endif
                        </div>
                        
                        <div class="form-group">
                            <input type="date" class="form-control" name="pasien_dob" placeholder="Pilih tanggal lahir" value="1990/05/12" style="background: white;" id="pasien_dob">
                            @if ($errors->has('pasien_dob'))
                                <span style="color: red">
                                    <strong>{{ $errors->first('pasien_dob') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <input type="number" class="form-control" name="pasien_id_number" placeholder="No. KTP" value="{{ old('pasien_id_number') }}" id="pasien_id_number">
                            @if ($errors->has('pasien_id_number'))
                                <span style="color: red">
                                    <strong>{{ $errors->first('pasien_id_number') }}</strong>
                                </span>
                            @endif
                        </div>
                    
                        <div class="form-group">
                            <input type="text" class="form-control" name="pasien_phone" placeholder="No. Telp" value="{{ old('pasien_phone') }}" id="pasien_phone">
                            @if ($errors->has('pasien_phone'))
                                <span style="color: red">
                                    <strong>{{ $errors->first('pasien_phone') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <input type="number" class="form-control" name="pasien_bpjs_number" placeholder="No. BPJS" value="{{ old('pasien_bpjs_number') }}" id="pasien_bpjs_number">
                            @if ($errors->has('pasien_bpjs_number'))
                                <span style="color: red">
                                    <strong>{{ $errors->first('pasien_bpjs_number') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="form-group">
                            <input type="file" class="form-control" name="document">
                            @if ($errors->has('document'))
                                <span style="color: red">
                                    <strong>{{ $errors->first('document') }}</strong>
                                </span>
                            @endif
                        </div>
                       
					</div>
				</aside>
            </div>

            <div class="col-md-4 col-sm-12">
				<aside>
					<div class="booking-form">
						<div class="booking-title">
							<h4>Detail Reservasi</h4>
						</div>
                        <div class="form-group">
                            <table class="table">
                                <tr>
                                    <td>Dokter</td>
                                    <td>: {{ $doctor->doctor_name }}</td>
                                </tr>
                                <tr>
                                    <td>Klinik/Poli</td>
                                    <td>: {{ $doctor->poli->poli_name }}</td>
                                </tr>
                                <tr>
                                    <td>Tgl. Reservasi</td>
                                    <td>: {{ date('l, d M Y', strtotime($date)) }}</td>
                                </tr>
                                <tr>
                                    <td>Waktu Praktek</td>
                                    <td>: {{ ucwords($time->time_type).' '.$time->time_schedule }}</td>
                                </tr>
                                
                            </table>
                        </div>
                        <div class="form-group">
                            <button type="submit" id="btn_check" class="booking-confirm hvr-shutter-out-horizontal btn_check"></i> Reservasi sekarang</button>
                        </div>
                    </div>
                </aside>

                <br>
                
                @if(session('error'))
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('error')}}
                </div>
                @endif
            </div>
        </div>
        {!! Form::close() !!}
	</div>
</section>
@endsection

@section('script')
    <script>
        function checkDataPasein(dom) {
            var pasien_email = $("#pasien_email").val();
            $.ajax({
                    url: '{{ URL::to("check/data-pasien") }}',
                    method:"POST",
                    data:{
                        pasien_email: pasien_email,
                    },
                    success:function(response) {
                        console.log(response)
                        if(response.status == 200) {
                            $("#no_rekam_medis").val(response.no_medis)
                            $("#pasien_name").val(response.data.pasien_name)
                            $("#pasien_dob").val(response.data.pasien_dob)
                            $("#pasien_id_number").val(response.data.pasien_id_number)
                            $("#pasien_phone").val(response.data.pasien_phone)
                            $("#pasien_bpjs_number").val(response.data.pasien_bpjs_number)

                            console.log(response.data.pasien_name)
                        }
                    },
                    error:function(){
                        alert("error");
                    }
                });
        }
    </script>
@endsection