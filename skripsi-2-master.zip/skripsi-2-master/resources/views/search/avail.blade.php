@extends('front_layout')
@section('content')

<section class="section-paddings popular-packages">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="section-title text-center">
					<h2>Rekomendasi Dokter</h2>
					<p>Pilih dokter paforit mu buat janji sesuai tanggal & waktu yang kamu inginkan.</p>
				</div>
			</div>
		</div>
		<!-- popular packages start-->
		<div class="row">
            @foreach($schDoctor as $doctor)
			<div class="col-sm-4 col-md-4">
				<div class="single-package">
					<div class="package-image">
                    <a href="#"><img src="{{ $doctor['doctor_image'] }}" alt="">
						</a>
					</div>
					<div class="package-content">
						<h3>{{ ucwords( $doctor['doctor_name']) }}</h3>
						<p>Spesialis : {{ ucwords($doctor['doctor_specialist']) }}</span>
						</p>
					</div>
					<div class="package-calto-action">
						<ul class="ct-action">
							<li><a href="{{ url('search/detail?dokter='.str_replace(' ', '-', $doctor['doctor_name']).'&id='.$doctor['doctor_id']) }}" class="travel-booking-btn hvr-shutter-out-horizontal">Lihat Jadwal Praktek</a>
							</li>
							<li>
								{{-- <i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i> --}}
							</li>
						</ul>
					</div>
				</div>
            </div>
            @endforeach
		</div> <!-- popular packages end-->
	</div>
</section> <!-- popular packajge start end -->


@endsection