@extends('front_layout')
@section('content')
<section class="section-paddings single-package-area">
	<div class="container">
		<div class="row">
			<!-- single package tab with details -->
			<div class="col-md-8 col-sm-12">
				<div class="single-package-details">
					<div class="single-package-title">
						<h2>{{ ucwords($doctor->doctor_name) }}</h2>
					</div>
					<ul class="package-content">
                        <li>Spesialis: {{ $doctor->doctor_specialist }}</li>
                        <li>NIK: {{ $doctor->doctor_nik }}</li>
						<li>Email : {{ $doctor->doctor_email }}</li>
						<li></li>
					</ul>
				</div><!-- tab menu strat -->

				<div class="package-tab-menu">
					<ul class="package-tab-menu" role="tablist" id="tab7">
						<li role="presentation" class="active"><a href="#description" aria-controls="description" role="tab" data-toggle="tab">Profile Dokter</a>
						</li>
						<li role="presentation"><a href="#itinerary" aria-controls="itinerary" role="tab" data-toggle="tab">Lokasi Praktek</a>
						</li>
					</ul>
				</div><!-- tab menu end -->

				<!-- tab content start -->
				<div class="row">
					<!-- tabs content -->
					<div class="tab-content">
						<div role="tabpanel" class="tab-pane fade in active" id="description">
							<div class="row">
								<!-- left content -->
								<div class="col-md-12 col-sm-12">
									<div class="tour-description">
                                    <p>{{ $doctor->doctor_desc }}</p>
                                    </div>
								</div><!-- left-content -->
							</div>
						</div>

						<div role="tabpanel" class="tab-pane fade" id="itinerary">
							<div class="row">
								<div class="col-md-12 col-sm-12">
									<div class="tour-description">
                                        <p>RS. Pusaka Sejahtera</p>
									</div>
								</div>
							</div>
						</div>
					</div><!-- tabs content-->
				</div><!-- tab content end -->
			</div><!-- single package tab with details -->

			<!-- booking form start here -->
			<div class="col-md-4 col-sm-12">
				<aside>
					<div class="booking-form">
						<div class="booking-title">
							<h2>Tanggal & Jam</h2>
						</div>
						<form class="check-avail">
							<?php 
							$dateNow = date('Y-m-d');
							$minDate = date('Y-m-d', strtotime('+5 days'. $dateNow))
							?>
							<div class="form-group">
								<input type="date" class="form-control" id="booking-date-2" name="date" placeholder="Pilih tanggal" min="{{ $minDate }}">
							</div>
							<div class="form-group">
								<table class="table">
                                    <p style="color: red" class="error-msg"></p>
                                    <input type="hidden" name="doctor_id" id="doctor_id" value="{{ $doctor->doctor_id }}">
                                    @foreach($time as $item) 
                                    <tr>
                                        <td>
                                            <input type="radio" name="time_id" id="time_id" value="{{ $item->time_id }}"> {{ucwords($item->time_type) }}
                                        </td>
                                        <td align="right">{{ $item->time_schedule }}</td>
                                    </tr>
                                    @endforeach
                                </table>
							</div>
							<div class="form-group">
								<button type="button" class="booking-confirm hvr-shutter-out-horizontal processing hide" disabled><i class="fa fa-spinner fa-spin"></i> Sedang diproses</button>
								<button type="button" id="btn_check" class="booking-confirm hvr-shutter-out-horizontal btn_check"></i> Buat Janji</button>
							</div>
						</form>
					</div>
				</aside>
			</div><!-- booking form end here -->
		</div>
	</div>
</section>
@endsection

@section('script')
    <script>
        $('#btn_check').click(function() {
            var doctorId = $("#doctor_id").val();
            var timeId = $("input[name='time_id']:checked").val();
            var date = $("#booking-date-2").val();
            if(typeof timeId == 'undefined') {
                $(".error-msg").text('Silahkan pilih tanggal & jam praktek terlebih dahulu');
            } else {
                $(".error-msg").text('')
                $(this).addClass('hide');
                $('.processing').removeClass('hide')
                $.ajax({
                    url: '{{ URL::to("search/check-avail") }}',
                    method:"POST",
                    data:{
                        time_id: timeId,
                        doctor_id: doctorId,
                        date: date

                    },
                    success:function(response) {
                        $(".error-msg").text();
                        console.log(response);
                        if (response.code == 200) {
                            window.location.href = response.data.url;
                        } else {
                            $(".error-msg").text(response.message);
                            $('.btn_check').removeClass('hide');
                            $('.processing').addClass('hide')
                        }
                    },
                    error:function(){
                        alert("error");
                    }
                });
            }
            
        });
    </script>
@endsection