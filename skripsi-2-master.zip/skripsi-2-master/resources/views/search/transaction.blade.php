@extends('front_layout')
@section('content')
<section class="section-paddings single-package-area">
	<div class="container">
        {!! Form::open(['route' => 'reservation', 'method' => 'post']) !!}
		<div class="row">
            <div class="col-md-8 col-sm-12">
				<aside>
					<div class="booking-form">
						<div class="booking-title">
                        <h4>No. Pemesanan: #{{ $transaction->transaction_code }}</h4>
                        <hr>
                        <h4>Data Pasien</h4>
                        <div class="form-group">
                            <table class="table">
                                <tr>
                                    <td colspan="2">No. Rekam Medis : {{ $transaction->transaction_no_medis }}</td>
                                </tr>
                                <tr>
                                    <td>Nama: {{ ucwords($transaction->pasien->pasien_name) }}</td>
                                    <td>No. Telp. : {{ $transaction->pasien->pasien_phone }}</td>
                                </tr>
                                <tr>
                                    <td>Email: {{ $transaction->pasien->pasien_email }}</td>
                                    <td>No. KTP. : {{ $transaction->pasien->pasien_id_number }}</td>
                                </tr>
                                <tr>
                                    <td>No. BPJS: {{ $transaction->pasien->pasien_bpjs_number }}</td>
                                    <td>Tgl. Lahir : {{ date('d M Y', strtotime($transaction->pasien->pasien_dob)) }}</td>
                                </tr>
                            </table>
                        </div>
					</div>
				</aside>
            </div>

            <div class="col-md-4 col-sm-12">
				<aside>
					<div class="booking-form">
						<div class="booking-title">
							<h4>Detail Reservasi</h4>
						</div>
                        <div class="form-group">
                            <table class="table">
                                <tr>
                                    <td>No. Antrian</td>
                                    <td>: {{ sprintf('%04d', $transaction->transaction_queue_number) }}</td>
                                </tr>
                                <tr>
                                    <td>Jam Konsultasi</td>
                                    <td>: {{ $transaction->transaction_queue_time }}</td>
                                </tr>
                                <tr>
                                    <td>Dokter</td>
                                    <td>: {{ $doctor->doctor_name }}</td>
                                </tr>
                                <tr>
                                    <td>Klinik/Poli</td>
                                    <td>: {{ $doctor->poli->poli_name }}</td>
                                </tr>
                                <tr>
                                    <td>Tgl. Reservasi</td>
                                    <td>: {{ date('l, d M Y', strtotime($transaction->transaction_schedule_date)) }}</td>
                                </tr>
                                <tr>
                                    <td>Waktu Praktek</td>
                                    <td>: {{ $transaction->transaction_time_type.' '.$transaction->transaction_schedule_time }}</td>
                                </tr>
                                <tr>
                                    <td>Status</td>
                                    <td>: {{ $transaction->status->status_name }}</td>
                                </tr>
                                
                            </table>
                        </div>
					</div>
				</aside>
            </div>
        </div>
        {!! Form::close() !!}
	</div>
</section>
@endsection

@section('script')
@endsection