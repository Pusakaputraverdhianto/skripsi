<div class="main-menu-area mg-tb-40">
    <div class="container">
        <div class="row">
            @if(isset($user['role']['menu']))
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <ul class="nav nav-tabs notika-menu-wrap menu-it-icon-pro">
                    @foreach($user['role']['menu'] as $key => $role)
                    <li class="{{($key==0)?"active":""}}"><a data-toggle="{{ (count($role['sub_menu']) > 0)?'tab':'' }}" href="{{ (count($role['sub_menu']) == 0)?url($role['menu_url']):'#'.$role['menu_url'] }}"><i class="notika-icon notika-house"></i> {{ ucfirst($role['menu_name']) }}</a>
                    </li>
                    @endforeach
                </ul>
                <div class="tab-content custom-menu-content">
                    @foreach($user['role']['menu'] as $key => $role)
                    <div id="{{ $role['menu_url'] }}" class="tab-pane notika-tab-menu-bg animated flipInX">
                        <ul class="notika-main-menu-dropdown">
                            @foreach($role['sub_menu'] as $item)
                            <li><a href="{{ url($item['menu_url']) }}">{{ $item['menu_name'] }}</a></li>
                            @endforeach
                        </ul>
                    </div>
                    @endforeach
                </div>
            </div>
            @endif
        </div>
    </div>
</div>