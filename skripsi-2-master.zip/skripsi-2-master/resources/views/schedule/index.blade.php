@extends('main_layout')
@section('content')
<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcomb-list">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcomb-wp">
                                <div class="breadcomb-icon">
                                    <i class="notika-icon notika-house"></i>
                                </div>
                                <div class="breadcomb-ctn">
                                    <h2>Jadwal Praktek</h2>
                                    <p>Jadwal Praktek Dokter dalam satu tahun.</span></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
                            <div class="breadcomb-report">
                                @if(FunctionsHelper::checkAction($menuId, 'create'))
                                <a href="{{ url('add-poli') }}" data-toggle="tooltip" data-placement="left" title="Tambah data" class="btn"><i class="notika-icon notika-plus-symbol"></i></a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcomb area End-->

<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                @if(session('success'))
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('success')}}
                </div>
                @endif

                @if(session('error'))
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"><i class="notika-icon notika-close"></i></span></button> 
                    {{session('error')}}
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- Data Table area Start-->
<div class="data-table-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="data-table-list">
                    <div class="basic-tb-hd">
                        <h4>Keterangan</h4>
                        <p>0 = Tidak ada jadwal praktek dokter.</p>
                        <p>1 = Ada jadwal praktek dokter.</p>
                    </div>
                    <div class="table-responsive">
                        <table id="data-table-basic" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Nama Dokter</th>
                                    <th>Tahun</th>
                                    <th>Bulan</th>
                                    <th>Hari</th>
                                    <th>Kehadiran</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($schedules as $key => $schedule)
                                <tr id="{{ ($schedule->schedule_avail == 0)?'not_avail':'' }}">
                                    {!! Form::open(['route' => 'updateSchedule', 'method' => 'post']) !!}
                                    <td>{{$key+1}}</td>
                                    <td>{{ucwords($schedule->doctor->doctor_name)}}</td>
                                    <td>{{$schedule->schedule_year}}</td>
                                    <td>{{$schedule->schedule_month}}</td>
                                    <td>{{$schedule->schedule_day}}</td>
                                    <td><input type="text" name="schedule_avail" value="{{$schedule->schedule_avail}}" style="width:20px;"></td>
                                    <td>
                                        <input type="hidden" name="doctor_id" value="{{$schedule->doctor->doctor_id}}">
                                        <input type="hidden" name="schedule_id" value="{{$schedule->schedule_id}}">
                                        <input type="hidden" name="schedule_year" value="{{$schedule->schedule_year}}">
                                        <input type="hidden" name="schedule_month" value="{{$schedule->schedule_month}}">
                                        <input type="hidden" name="schedule_day" value="{{$schedule->schedule_day}}">
                                        <button class="btn btn-success notika-btn-success"><i class="notika-icon notika-sent"></i> Simpan</button>
                                    </td>
                                    {!! Form::close() !!}
                                </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="6"></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="confirmationDelete" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body">
                <h2>Konfirmasi.</h2>
                <p>Apakah anda yakin ingin menghapus data ini ?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default agree-action" data-dismiss="modal">Yakin</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
    <script>
        function confirmationDelete(dom) {
            $(".agree-action").click(function () {
                window.location = dom.dataset.href;
            });
        }
    </script>
@endsection