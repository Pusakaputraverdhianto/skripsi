Selamat, reservasi anda berhasil diproses.<br>
Berikut detail data reservasi. <br><br>

No. reservasi anda : {{ $transaction_code }} <br>
No. antrian : {{ $nomor_antrian }} <br>
Jam Konsultasi : {{ $jam_konsultasi }} <br>
Cek reservasi anda disini : <a href="{{ $link_reservasi }}">Link Cek Reservasi</a> <br><br>

Catatan: Status pendaftaran/reservasi anda masih menunggu konfimasi dan pengecekan data oleh petugas, silahkan cek secara berkala pada link diatas dengan memasukan nomor reservasi anda.


<br><br>

Terimakasih.