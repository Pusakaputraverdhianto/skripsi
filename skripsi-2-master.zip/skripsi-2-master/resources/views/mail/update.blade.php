Mohon maaf, kami informasikan bahwa ada perubahan jadwal konsultasi.<br><br>

Detail perubahan jadwal : <br>
No. Reservasi anda : {{ $transaction_code }} <br>
No. Antrian : {{ $nomor_antrian }} <br>
Tanggal Konsultasi: {{ $transaction_schedule_date }} <br>
Jam Konsultasi Sebelumnya: {{ $jam_konsultasi }} <br>
Jam Konsultasi Baru: {{ $jam_konsultasi_baru }} <br>
Cek reservasi anda disini : <a href="{{ $link_reservasi }}">Link Cek Reservasi</a> <br><br>

Terimakasih.