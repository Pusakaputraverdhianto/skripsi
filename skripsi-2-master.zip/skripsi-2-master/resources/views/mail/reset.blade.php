Berikut adalah password baru anda. <br>Silahkan lakukan perubahan password setelah anda login. <br><br>
Password baru : {{ $password }}
<br><br>
Terimakasih.