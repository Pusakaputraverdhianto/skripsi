(function ($) {
 "use strict";
	
	$(document).ready(function() {
		//  $('#data-table-basic').dataTable();
		let excelButtonTrans = 'Download Excel'
		let pdfButtonTrans = 'Pdf'
		let printButtonTrans = 'Print'
		$('#data-table-basic').dataTable({
			dom: 'lBfrtip',
			searchable: true,
			buttons: [
				{
					extend: 'excel',
					className: 'btn btn-default',
					text: excelButtonTrans,
					exportOptions: {
					columns: ':visible'
					}
				}
			]
		});
	});
 
})(jQuery); 