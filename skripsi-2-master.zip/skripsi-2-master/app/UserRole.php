<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserRole extends Model
{
    protected $table = 'user_role';

    public function role()
    {
        return $this->hasOne('App\Role', 'roles_id', 'role_id');
    }

    public $timestamps = false;
}
