<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubMenu extends Model
{
    protected $table = "sub_menu";

    public function scopeActive($query)
    {
        return $query->where('sub_menu_status', 1);
    }
}
