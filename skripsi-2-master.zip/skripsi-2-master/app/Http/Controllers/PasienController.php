<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Pasien;
use App\Transaction;

class PasienController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth'])->except('checkDataPasien');
    }

    public function index()
    {
        $pasien = Pasien::orderBy('pasien_id', 'desc')->get();
        return view('pasien.index', compact('pasien'));
    }

    public function checkDataPasien(Request $request)
    {
        $pasien = Pasien::where('pasien_email', $request->pasien_email)->first();
        if ($pasien) {
            $transaction = Transaction::where('pasien_id', $pasien->pasien_id)->first();
            return [
                'status' => 200,
                'data' => $pasien,
                'no_medis' => $transaction->transaction_no_medis
            ];
        }
        return [
            'status' => 202
        ];
    }
}
