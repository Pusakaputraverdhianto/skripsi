<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Route;
use App\Helpers\FunctionsHelper;
use App\Time;
use Validator;
use DB;
use URL;

class TimeController extends Controller
{
    protected $role;

    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
    }

    public function index($id)
    {
        $route = Route::current()->uri();
        $isRole = FunctionsHelper::checkRole($route);
        $menuId = $isRole['menu_id'];
        $this->role = $isRole['status'];
        $times = Time::where('doctor_id', $id)->get();
        $doctorId = $id;
        
        return view('time.index', compact('menuId', 'times', 'doctorId'));
    }

    public function create($id)
    {
        return view('time.create', compact('id'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'time_type' => 'required',
            'time_schedule' => 'required',
            'limit_pasien' => 'required|numeric'
        ]);

        if ($validator->fails()) {
            return redirect('time/create/'.$request->doctor_id)
                        ->withErrors($validator)
                        ->withInput();
        }
        
        DB::beginTransaction();
        try {
            $time = new Time();
            $time->time_type = $request->time_type;
            $time->time_schedule = $request->time_schedule;
            $time->doctor_id = $request->doctor_id;
            $time->time_limit_pasien = $request->limit_pasien;
            $time->save();

            DB::commit();
            return redirect(URL::to('doctor'))->with('success', 'Waktu prakte baru berhasil ditambahkan.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $time = Time::where('time_id', $id)->first();
        return view('time.edit', compact('time'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'time_type' => 'required|max:10',
            'time_schedule' => 'required|max:20',
            'limit_pasien' => 'required|numeric'
        ]);

        if ($validator->fails()) {
            return redirect('time/edit/'.$id)
                        ->withErrors($validator)
                        ->withInput();
        }

        try {
            Time::where('time_id', $id)->update([
                'time_type' => $request->time_type,
                'time_schedule' => $request->time_schedule,
                'time_limit_pasien' => $request->limit_pasien,
            ]);

            return redirect(URL::to('doctor'))->with('success', 'Data berhasil diupdate.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function destroy($id)
    {
        try {
            Time::where('time_id', $id)->delete();
            return redirect(URL::to('doctor'))->with('success', 'Data berhasil dihapus.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }
}
