<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Route;
use App\Helpers\FunctionsHelper;
use Auth;
use Validator;
use URL;
use DB;
use App\Doctor;
use App\Schedule;
use App\Poli;
use Intervention\Image\Facades\Image;


class DoctorControllerr extends Controller
{
    protected $role;

    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $route = Route::current()->uri();
        $isRole = FunctionsHelper::checkRole($route);
        $menuId = $isRole['menu_id'];
        $this->role = $isRole['status'];
        $doctors = Doctor::orderBy('updated_at', 'DESC')->get();
        
        return view('doctor.index', compact('menuId', 'doctors'));
    }

    public function create()
    {
        $poli = Poli::select(['poli_id', 'poli_name'])->get();
        return view('doctor.create', compact('poli'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'doctor_nik' => 'required|string|max:50',
            'doctor_name' => 'required|string|max:100',
            'doctor_email' => 'required|string|max:100:unique:doctor',
            'doctor_phone' => 'required|string|max:20',
            'doctor_address' => 'required',
            'doctor_desc' => 'required',
            'doctor_specialist' => 'required|string|max:50',
            'poli' => 'required|numeric',
            'image' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect('add-doctor')
                        ->withErrors($validator)
                        ->withInput();
        }
        
        DB::beginTransaction();
        try {
            $file = $request->file('image');
            $fileName = date('YmdHis') . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $canvas = Image::canvas('400', '400');
            $resizeThumbs  = Image::make($file)->resize('400', '400', function($constraint) {
                $constraint->aspectRatio();
            });
            $canvas->insert($resizeThumbs, 'center');
            $canvas->save(config('constants.IMAGE_PATH') . $fileName);

            $doctor = new Doctor();
            $doctor->doctor_name = $request->doctor_name;
            $doctor->doctor_nik = $request->doctor_nik;
            $doctor->doctor_email = $request->doctor_email;
            $doctor->doctor_phone = $request->doctor_phone;
            $doctor->doctor_address = $request->doctor_address;
            $doctor->doctor_desc = $request->doctor_desc;
            $doctor->doctor_image = URL::asset('images/'.$fileName);
            $doctor->doctor_specialist = $request->doctor_specialist;
            $doctor->poli_id = $request->poli;
            $doctor->save();

            // generate jadwal praktek
            $this->generateSchedule();

            DB::commit();
            return redirect(URL::to('doctor'))->with('success', 'Data baru berhasil ditambahkan.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $doctor = Doctor::where('doctor_id', $id)->first();
        $poli = Poli::get();
        return view('doctor.edit', compact('poli', 'doctor'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'doctor_nik' => 'required|string|max:50',
            'doctor_name' => 'required|string|max:100',
            'doctor_email' => 'required|string|max:100:unique:doctor',
            'doctor_phone' => 'required|string|max:20',
            'doctor_address' => 'required',
            'doctor_desc' => 'required',
            'doctor_specialist' => 'required|string|max:50',
            'poli' => 'required|numeric'
        ]);

        if ($validator->fails()) {
            return redirect('doctor/edit/'.$id)
                        ->withErrors($validator)
                        ->withInput();
        }

        try {

            if (!is_null($request->image)) 
            {
                $file = $request->file('image');
                $fileName = date('YmdHis') . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                $canvas = Image::canvas('400', '400');
                $resizeThumbs  = Image::make($file)->resize('400', '400', function($constraint) {
                    $constraint->aspectRatio();
                });
                $canvas->insert($resizeThumbs, 'center');
                $canvas->save(config('constants.IMAGE_PATH') . $fileName);
                $param['doctor_image'] = URL::asset('images/'.$fileName);
            }

            $param['doctor_nik'] = $request->doctor_nik;
            $param['doctor_name'] = $request->doctor_name;
            $param['doctor_email'] = $request->doctor_email;
            $param['doctor_phone'] = $request->doctor_phone;
            $param['doctor_address'] = $request->doctor_address;
            $param['doctor_desc'] = $request->doctor_desc;
            $param['doctor_specialist'] = $request->doctor_specialist;
            $param['poli_id'] = $request->poli;

            Doctor::where('doctor_id',$id)->update($param);

            return redirect(URL::to('doctor'))->with('success', 'Data berhasil diupdate.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function destroy($id)
    {
        try {
            Doctor::where('doctor_id', $id)->delete();
            return redirect(URL::to('doctor'))->with('success', 'Data berhasil dihapus.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    private function generateSchedule()
    {
        $year = date('Y');
        $doctors = Doctor::all();
        foreach($doctors as $key => $doctor)
        {
            // check shcedule /doctor
            $shceduleExist = Schedule::where('doctor_id', $doctor->doctor_id)->where('schedule_year', $year)->get();
            if (count($shceduleExist) == 0) {
                for ($i=1; $i <= 12; $i++) { 
                    $totalDay = cal_days_in_month(CAL_GREGORIAN, $i, $year);
                    $param = [];
                    for ($j=1; $j <= $totalDay; $j++) { 
                        $param[] = [
                            'doctor_id' => $doctor->doctor_id,
                            'schedule_year' => $year,
                            'schedule_month' => $i,
                            'schedule_day' => $j,
                            'schedule_avail' => 1,
                            'created_at' => date('Y-m-d H:i:s'),
                            'updated_at' => date('Y-m-d H:i:s')
                        ];
                    }
                    $schedule = new Schedule();
                    $schedule->insert($param);
                }
            }
        }
    }
}
