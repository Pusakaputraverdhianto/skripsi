<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Doctor;
use App\Schedule;
use Route;
use App\Helpers\FunctionsHelper;
use URL;

class ScheduleController extends Controller
{
    protected $role;

    public function __construct(Request $request)
    {
        $this->middleware('auth', ['except' => 'generateSchedule']);
    }
   
    public function index($id)
    {
        $route = Route::current()->uri();
        $isRole = FunctionsHelper::checkRole($route);
        $menuId = $isRole['menu_id'];
        $this->role = $isRole['status'];
        $schedules = Schedule::where('doctor_id', $id)
            ->with('doctor')->get();

        return view('schedule.index', compact('schedules', 'menuId'));
    }

    public function generateSchedule()
    {
        $year = date('Y');
        $doctors = Doctor::all();
        foreach($doctors as $key => $doctor)
        {
            // check shcedule /doctor
            $shceduleExist = Schedule::where('doctor_id', $doctor->doctor_id)->where('schedule_year', $year)->get();
            if (count($shceduleExist) == 0) {
                for ($i=1; $i <= 12; $i++) { 
                    $totalDay = cal_days_in_month(CAL_GREGORIAN, $i, $year);
                    $param = [];
                    for ($j=1; $j <= $totalDay; $j++) { 
                        echo "hari ".$j.'<br>';
                        $param[] = [
                            'doctor_id' => $doctor->doctor_id,
                            'schedule_year' => $year,
                            'schedule_month' => $i,
                            'schedule_day' => $j,
                            'schedule_avail' => 1,
                            'created_at' => date('Y-m-d H:i:s'),
                            'updated_at' => date('Y-m-d H:i:s')
                        ];
                    }
                    $schedule = new Schedule();
                    $schedule->insert($param);
                }
            }
        }
    }

    public function updateSchedule(Request $request)
    {
        try {
            Schedule::where('schedule_id', $request->schedule_id)
            ->where('schedule_year', $request->schedule_year)
            ->where('schedule_month', $request->schedule_month)
            ->where('schedule_day', $request->schedule_day)
            ->where('doctor_id', $request->doctor_id)
            ->update([
                'schedule_avail' => $request->schedule_avail
            ]);

            \Artisan::call('cache:clear');
            return redirect(URL::to('doctor'))->with('success', 'Data berhasil disimpan.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }
}
