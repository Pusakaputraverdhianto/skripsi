<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Route;
use App\Helpers\FunctionsHelper;
use App\User;
use App\Role;
use Auth;
use Validator;
use URL;
use App\UserRole;
use DB;

class UserController extends Controller
{
    protected $role;

    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $route = Route::current()->uri();
        $isRole = FunctionsHelper::checkRole($route);
        $menuId = $isRole['menu_id'];
        $this->role = $isRole['status'];
        $users = User::with('role')->get();
        
        return view('user.index', compact('menuId', 'users'));
    }

    public function create()
    {
        $roles = Role::all();
        return view('user.create', compact('roles'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6',
            'role' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect('add-user')
                        ->withErrors($validator)
                        ->withInput();
        }
        
        DB::beginTransaction();
        try {
            $user = new User();
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = FunctionsHelper::hashPassword($request->password);
            $user->status = 2;
            $user->role_id = $request->role;
            $user->save();

            DB::commit();
            return redirect(URL::to('user'))->with('success', 'User baru berhasil ditambahkan.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $roles = Role::all();
        $dataUser = User::where('id', $id)->first();
        return view('user.edit', compact('dataUser', 'roles'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255',
            'role' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect('user/edit/'.$id)
                        ->withErrors($validator)
                        ->withInput();
        }

        try {
            $data['name'] = $request->name;
            $data['email'] = $request->email;
            $data['role_id'] = $request->role;
            $data['status'] = $request->status;
            if ($request->password != null) {
                $data['password'] = FUnctionsHelper::hashPassword($request->password);
            }
            $user = User::where('id',$id)->update($data);

            return redirect(URL::to('user'))->with('success', 'Data berhasil diupdate.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function destroy($id)
    {
        try {
            $user = User::where('id', $id)->delete();
            return redirect(URL::to('user'))->with('success', 'Data berhasil dihapus.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }
}
