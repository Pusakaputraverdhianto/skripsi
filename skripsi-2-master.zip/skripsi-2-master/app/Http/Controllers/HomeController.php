<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;
use Auth;
use App\Helpers\FunctionsHelper;
use App\User;
use App\Doctor;
use App\Poli;
use App\Pasien;
use App\Transaction;
use Route;

class HomeController extends Controller
{
    protected $isRole;
    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
    }
    
    public function index()
    {
        $route = Route::current()->uri();
        $this->isRole = $isRole = FunctionsHelper::checkRole($route);
        $menuId = $this->isRole['menu_id'];
        if ($this->isRole['status'] == false) {
            return "Anda tidak memiliki akses.";
        }

        $doctor = Doctor::count();
        $poli = Poli::count();
        $pasien = Pasien::count();
        $transaction = Transaction::count();

        return view('home.index', compact('menuId', 'doctor', 'poli', 'pasien', 'transaction'));
    }
}
