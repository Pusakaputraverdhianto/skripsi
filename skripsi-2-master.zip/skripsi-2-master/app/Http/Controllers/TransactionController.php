<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Transaction;
use App\Doctor;
use DB;
use URL;
use App\Helpers\FunctionsHelper;
use Validator;

class TransactionController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $transactions = Transaction::with('pasien', 'doctor', 'status')->orderBy('transaction_id', 'desc')->get();
        return view('transaction.index', compact('transactions'));
    }

    public function updateJadwalReservasi()
    {
        $doctor = Doctor::get();
        return view('transaction.update_reservasi', compact('doctor'));
    }

    public function store(Request $request) 
    {
        $validator = Validator::make($request->all(), [
            'doctor' => 'required',
            'time_type' => 'required',
            'consultation_date' => 'required',
            'new_time' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }

        DB::beginTransaction();
        try {
            $transactions = Transaction::where('doctor_id', $request->doctor)
            ->where('transaction_time_type', $request->time_type)
            ->whereDate('transaction_schedule_date', $request->consultation_date)
            ->with('pasien')
            ->get();

            Transaction::where('doctor_id', $request->doctor)
            ->where('transaction_time_type', $request->time_type)
            ->whereDate('transaction_schedule_date', $request->consultation_date)
            ->update([
                'transaction_schedule_time' => $request->new_time
            ]);

            foreach($transactions as $item)
            {
                $param = [
                    'to_name' => $item->pasien->pasien_name,
                    'to_mail' => $item->pasien->pasien_email,
                    'subject' => 'Perubahan Jadwal - '.$item->transaction_code,
                    'transaction_code' => $item->transaction_code,
                    'nomor_antrian' => sprintf('%04d', $item->transaction_queue_number),
                    'transaction_schedule_date' => date('d M Y', strtotime($item->transaction_schedule_date)),
                    'jam_konsultasi' => date('H:i:s', strtotime($item->transaction_schedule_time)),
                    'jam_konsultasi_baru' => date('H:i:s', strtotime($request->new_time)),
                    'link_reservasi' => URL::to('search/reservation')
                ];
                FunctionsHelper::sendMail($param, 'mail.update');
            }

            DB::commit();

            return redirect()->back()->with('success', 'Jadwal Konsultasi berhasil di update');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()->with('error', $th->getMessage())->withInput();
        }
    }

    public function changeStatus(Request $request)
    {
        try {
            Transaction::where('transaction_id', $request->transaction_id)->update([
                'transaction_status' => $request->transaction_status
            ]);

            return [
                'status' => 200
            ];
        } catch (\Throwable $th) {
            return [
                'status' => 202,
                'message' => $th->getMessage()
            ];
        }
    }
}
