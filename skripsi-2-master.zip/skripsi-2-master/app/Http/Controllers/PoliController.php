<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Route;
use App\Helpers\FunctionsHelper;
use Auth;
use Validator;
use URL;
use DB;
use App\Poli;
use Intervention\Image\Facades\Image;

class PoliController extends Controller
{
    protected $role;

    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $route = Route::current()->uri();
        $isRole = FunctionsHelper::checkRole($route);
        $menuId = $isRole['menu_id'];
        $this->role = $isRole['status'];
        $poli = Poli::orderBy('updated_at', 'DESC')->get();
        
        return view('poli.index', compact('menuId', 'poli'));
    }

    public function create()
    {
        return view('poli.create');
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'poli_name' => 'required|string|max:255',
            'poli_code' => 'required|string|max:20',
            'poli_desc' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect('add-poli')
                        ->withErrors($validator)
                        ->withInput();
        }
        
        DB::beginTransaction();
        try {
            $file = $request->file('image');
            $fileName = date('YmdHis') . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $canvas = Image::canvas('400', '400');
            $resizeThumbs  = Image::make($file)->resize('400', '400', function($constraint) {
                $constraint->aspectRatio();
            });
            $canvas->insert($resizeThumbs, 'center');
            $canvas->save(config('constants.IMAGE_PATH') . $fileName);

            $poli = new Poli();
            $poli->poli_name = $request->poli_name;
            $poli->poli_desc = $request->poli_desc;
            $poli->poli_code = $request->poli_code;
            $poli->poli_image = URL::asset('images/'.$fileName);
            $poli->save();

            DB::commit();
            return redirect(URL::to('poli'))->with('success', 'Data poli baru berhasil ditambahkan.');
        } catch (\Throwable $th) {
            DB::rollback();
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function edit($id)
    {
        $poli = Poli::where('poli_id', $id)->first();
        return view('poli.edit', compact('poli'));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'poli_name' => 'required|string|max:255',
            'poli_code' => 'required|string|max:20',
            'poli_desc' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect('poli/edit/'.$id)
                        ->withErrors($validator)
                        ->withInput();
        }

        try {
            if (!is_null($request->image)) 
            {
                $file = $request->file('image');
                $fileName = date('YmdHis') . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                $canvas = Image::canvas('400', '400');
                $resizeThumbs  = Image::make($file)->resize('400', '400', function($constraint) {
                    $constraint->aspectRatio();
                });
                $canvas->insert($resizeThumbs, 'center');
                $canvas->save(config('constants.IMAGE_PATH') . $fileName);
                $param['poli_image'] = URL::asset('images/'.$fileName);
            }
            $param['poli_name'] = $request->poli_name;
            $param['poli_code'] = $request->poli_code;
            $param['poli_desc'] = $request->poli_desc;

            Poli::where('poli_id',$id)->update($param);

            return redirect(URL::to('poli'))->with('success', 'Data berhasil diupdate.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }

    public function destroy($id)
    {
        try {
            Poli::where('poli_id', $id)->delete();
            return redirect(URL::to('poli'))->with('success', 'Data berhasil dihapus.');
        } catch (\Throwable $th) {
            return redirect()->back()->withInput()->with('error', $th->getMessage());
        }
    }
}
