<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Poli;
use App\Doctor;
use App\Schedule;
use App\Time;
use App\Pasien;
use App\Transaction;
use App\User;
use Validator;
use DB;
use URL;
use App\Helpers\FunctionsHelper;
use Intervention\Image\Facades\Image;


class SearchController extends Controller
{
    public function __construct()
    {
        
    }

    public function index()
    {
        $poli = Poli::select(['poli_id', 'poli_name', 'poli_image'])->get();
        return view('search.index', compact('poli'));
    }

    public function doSearch(Request $request)
    {
        if (is_null($request->poli_id)) {
            return redirect('search')->with('error', 'Silahkan pilih poli terlebih dahulu.');
        }
        return redirect('search/avail?poli='.$request->poli_id);
    }

    public function avail(Request $request)
    {
        $poli = Poli::where('poli_id', $request->poli)->first();
        $doctors = Doctor::select(['doctor_id', 'doctor_name', 'doctor_specialist', 'doctor_desc', 'doctor_image'])
            ->where('poli_id', $poli->poli_id)->get();

        $now = date('Y-m-d');
        $date = date('Y-m-d', strtotime("+5 day", strtotime($now)));

        $year = (int)date('Y', strtotime($date));
        $month = (int)date('m', strtotime($date));
        $day = (int)date('d', strtotime($date));

        $schDoctor = [];
        foreach($doctors as $doctor)
        {
            $schedule = Schedule::where('schedule_year', $year)
                ->where('schedule_month', $month)
                ->where('schedule_day', $day)
                ->where('schedule_avail', 1)
                ->where('doctor_id', $doctor->doctor_id)
                ->first();
            if (!empty($schedule)) 
            {
                $schDoctor[] = $doctor->toArray();
            }
        }

        return view('search.avail', compact('schDoctor'));
    }

    public function detail(Request $request)
    {
        $doctor = Doctor::where('doctor_id', $request->id)->first();
        // return $doctor;
        $now = date('Y-m-d');
        $date = date('Y-m-d', strtotime("+5 day", strtotime($now)));

        $year = (int)date('Y', strtotime($date));
        $month = (int)date('m', strtotime($date));
        $day = (int)date('d', strtotime($date));

        $schedule = Schedule::where('schedule_year', $year)
                ->where('schedule_month', $month)
                ->where('schedule_day', $day)
                ->where('schedule_avail', 1)
                ->where('doctor_id', $doctor->doctor_id)
                ->first();
        $time = Time::select(['time_id', 'time_type', 'time_schedule'])->where('doctor_id', $doctor->doctor_id)->get();
        return view('search.detail', compact('time', 'doctor'));
    }

    public function checkAvail(Request $request)
    {
        $date = date('Y-m-d', strtotime($request->date));
        $now = date('Y-m-d');
        $dateTemp = date('Y-m-d', strtotime("+5 day", strtotime($now)));

        if (strtotime($date) < strtotime($dateTemp)) 
        {
            return [
                'code' => 404,
                'message' => 'Jadwal praktek tidak tersedia, silahkan pilih tanggal lain (min. +5 dari hari ini)',
                'data' => []
            ];
        }

        $year = (int)date('Y', strtotime($date));
        $month = (int)date('m', strtotime($date));
        $day = (int)date('d', strtotime($date));
        $schedule = Schedule::where('schedule_year', $year)
            ->where('schedule_month', $month)
            ->where('schedule_day', $day)
            ->where('schedule_avail', 1)
            ->where('doctor_id', $request->doctor_id)
            ->first();

        if (empty($schedule)) {
            return [
                'code' => 404,
                'message' => 'Jadwal dokter pada tanggl '.$date.' tidak tersedia',
                'data' => []
            ];
        }
        $time = Time::where('time_id', $request->time_id)->first();
        if (empty($schedule)) {
            return [
                'code' => 404,
                'message' => 'Jam praktek dokter tidak tersedia',
                'data' => []
            ];
        }

        $data['schedule_id'] = $schedule->schedule_id;
        $data['time_id'] = $time->time_id;
        $data['doctor_id'] = $request->doctor_id;
        $data['date'] = strtotime($request->date);
        $data['schedule_id'] = $schedule->schedule_id;
        $query = http_build_query($data, '&');

        return [
            'code' => 200,
            'message' => 'Jadwal tersedia',
            'data' => [
                'url' => url('search/data-pasien?'.$query)
            ]
        ];
    }

    public function reservation(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'pasien_name' => 'required',
            'pasien_dob' => 'required',
            'pasien_id_number' => 'required|numeric',
            'pasien_email' => 'required',
            'pasien_phone' => 'required|numeric',
            'pasien_bpjs_number' => 'required|numeric',
            'document' => 'required',
            'no_rekam_medis' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $code = "";
        DB::beginTransaction();
        try {
            $pasienData = Pasien::where('pasien_email', $request->pasien_email)->first();
            if (empty($pasienData)) {
                // $user = new User();
                // $user->role_id = 1;
                // $user->name = $request->pasien_name;
                // $user->email = $request->pasien_email;
                // $user->password = FunctionsHelper::hashPassword($request->pasien_id_number);
                // $user->status = 1;
                // $user->save();

                $pasien = new Pasien();
                // $pasien->pasien_id = $user->user_id;
                $pasien->pasien_name = $request->pasien_name;
                $pasien->pasien_dob = date('Y-m-d', strtotime($request->pasien_dob));
                $pasien->pasien_id_number = $request->pasien_id_number;
                $pasien->pasien_email = $request->pasien_email;
                $pasien->pasien_phone = $request->pasien_phone;
                $pasien->pasien_bpjs_number = $request->pasien_bpjs_number;
                $pasien->save();
                $pasienId = $pasien->pasien_id;
            } else {
                $pasienId = $pasienData->pasien_id;
            }

            $doctor = Doctor::where('doctor_id', $request->doctor_id)->with('poli')->first();
            $schedule = Schedule::where('schedule_id', $request->schedule_id)->where('doctor_id', $request->doctor_id)->first();
            $time = Time::where('time_id', $request->time_id)->first();

            $paramDate = $schedule->schedule_year.'-'.$schedule->schedule_month.'-'.$schedule->schedule_day;
            $date = date('Y-m-d', strtotime($paramDate));

            // start image
            $file = $request->file('document');
            $fileName = date('YmdHis') . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $canvas = Image::canvas('400', '400');
            $resizeThumbs  = Image::make($file)->resize('400', '400', function($constraint) {
                $constraint->aspectRatio();
            });
            $canvas->insert($resizeThumbs, 'center');
            $canvas->save(config('constants.IMAGE_PATH') . $fileName);
            // end image

            // cek kuota
            $transactionData = Transaction::whereDate('transaction_schedule_date', $date)
                ->orderBy('transaction_id', 'desc')
                ->where('transaction_schedule_time', $time->time_schedule)
                ->get();

            if (count($transactionData) >= $time->time_limit_pasien) 
            {
                DB::rollback();
                return redirect('search/data-pasien?schedule_id='.$request->schedule_id.'&time_id='.$request->time_id.'&doctor_id='.$request->doctor_id.'&date='.strtotime($request->date))
                ->withInput()    
                ->with('error', 'Reservasi anda tidak dapat diproses karena kuota penuh, silahkan cari tanggal atau jam praktek lain.');
            }

            $queueNumber = 1;
            if (count($transactionData) > 0) 
            {
                $queueNumber = $transactionData[0]->transaction_queue_number + 1;
            }

            $newTimeSchedule = date('H.i.s', strtotime($time->time_schedule));

            $queueTime = $queueNumber * 15;
            $transactionCode = 'RO/'.date('Ymd').'/'.date('Ymd', strtotime($date)).'/'.$doctor->poli->poli_code.'/'.sprintf('%04d', $queueNumber);
            $transactionReference = md5($doctor->doctor_id.'|'.$schedule->schedule_id.'|'.$time->time_id.microtime());
            $transaction = new Transaction();
            $transaction->pasien_id = $pasienId;
            $transaction->transaction_code = $transactionCode;
            $transaction->transaction_reference = $transactionReference;
            $transaction->transaction_time_type = $time->time_type;
            $transaction->doctor_id = $request->doctor_id;
            $transaction->transaction_schedule_date = $date;
            $transaction->transaction_schedule_time = $time->time_schedule;
            $transaction->transaction_status = 3;
            $transaction->transaction_no_medis = $request->no_rekam_medis;
            $transaction->transaction_queue_number = $queueNumber;
            $transaction->transaction_queue_time = date('H:i:s', strtotime($newTimeSchedule."+".$queueTime." minutes"));
            $transaction->transaction_document = URL::asset('images/'.$fileName);
            $transaction->save();

            $param = [
                'to_name' => $request->pasien_name,
                'to_mail' => $request->pasien_email,
                'subject' => $transactionCode,
                'transaction_code' => $transactionCode,
                'nomor_antrian' => sprintf('%04d', $queueNumber),
                'jam_konsultasi' => date('H:i:s', strtotime($newTimeSchedule."+".$queueTime." minutes")),
                'link_reservasi' => URL::to('search/reservation')
            ];
            FunctionsHelper::sendMail($param, 'mail.mail');

            DB::commit();
            return redirect('transaction/'.$transactionReference);
        } catch (\Throwable $th) {
            DB::rollback();
            
            return redirect('search/data-pasien?schedule_id='.$request->schedule_id.'&time_id='.$request->time_id.'&doctor_id='.$request->doctor_id.'&date='.strtotime($request->date))
                ->withInput()
                ->with('error', $th->getMessage());
        }
    }

    public function dataPasien(Request $request)
    {
        $doctor = Doctor::where('doctor_id', $request->doctor_id)->with('poli')->first();
        $time = Time::where('time_id', $request->time_id)->first();
        $schedule = Schedule::where('schedule_id', $request->schedule_id)->where('doctor_id', $request->doctor_id)->first();
        $date = date('Y-m-d', $request->date);

        return view('search.data_pasien', compact('doctor', 'time', 'schedule', 'date'));
    }

    public function transaction($code)
    {
        $transaction = Transaction::where('transaction_reference', $code)
            ->with(['doctor' => function($query) {
                $query->with('poli');
            }])
            ->with('pasien', 'status')
            ->first();

        $doctor = $transaction->doctor;
        return view('search.transaction', compact('doctor', 'transaction'));
    }

    public function transactionHistory(Request $request)
    {
        try {
            $transaction = Transaction::where('transaction_code', $request->transaction_code)
            ->with(['doctor' => function($query) {
                $query->with('poli');
            }])
            ->with('pasien')
            ->first();

            $doctor = $transaction->doctor;
            return redirect('transaction/'.$transaction->transaction_reference);
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', 'No. Reservasi '.$request->transaction_code.' tidak ditemukan. Silahkan masukkan No. Reservasi yang benar.');
        }
    }

    public function reservationCheck()
    {
        return view('search.cek_reservasi');
    }
}
