<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Doctor extends Model
{
    protected $table = 'doctor';

    public function poli()
    {
        return $this->hasOne('App\Poli', 'poli_id', 'poli_id');
    }
}
