<?php
namespace App\Helpers;

use App\User;
use App\Menu;
use App\Action;
use App\RoleMenuAction;
use Auth;
use Illuminate\Support\Facades\Redis;
use Mail;

class FunctionsHelper
{
    public static function hashPassword($key)
    {
        $hash = hash('sha512', (substr(md5($key), 4, 15)));
        return $hash;
    }

    public static function userDetail($user)
    {
        $dataUser = User::where('id', $user->id)
            ->active()
             ->with(['role' => function($subQuery) {
                $subQuery->with(['roleMenu' => function($subQuery2) {
                    $subQuery2->with(['menu' => function($query3) {
                        $query3->active();
                        $query3->whereNull('parent_id');
                    }]);
                }]);
            }])
            ->first();
        if (empty($dataUser)) {
            return false;
        }

        $role = [];
        if (isset($dataUser->role)) {
            $menus = [];
            $subMenu = [];
            foreach ($dataUser->role->roleMenu as $key => $value) 
            {
                if ($value->menu == null) {
                    $data = Menu::active()->where('menu_id', $value->menu_id)->first();
                    if (!empty($data)) {
                        $subMenu[] = $data->toArray();
                    }
                }

                if ($value->menu != null) {
                    $menus[] = [
                        'menu_id' => $value->menu->menu_id,
                        'menu_icon' => $value->menu->menu_icon,
                        'menu_name' => $value->menu->menu_name,
                        'menu_url' => $value->menu->menu_url
                    ];
                }
            }

            foreach($menus as $index => $menu)
            {
                $subMenuTmp = [];
                foreach($subMenu as $idx => $sub)
                {
                    if ($menu['menu_id'] == $sub['parent_id']) {
                        $subMenuTmp[] = $sub;
                    }
                }
                $menus[$index]['sub_menu'] = $subMenuTmp;
            }

            $role = [
                'role_id' => $dataUser->role->roles_id,
                'role_name' => $dataUser->role->roles_name,
                'menu' => $menus
            ];
        }
        $userAccess = [
            'user_id' => $dataUser->id,
            'user_name' => $dataUser->name,
            'user_email' => $dataUser->email,
            'role' => $role,
        ];
        return $userAccess;
    }

    public static function dataRedis()
    {
        if (is_null(Auth::user())) {
            return [];
        }
        $redis = Redis::get(config('constants.REDIS_ACCESS').Auth::user()->id);
        $user = json_decode($redis, true);
        return $user;
    }

    public static function checkAction($menuId = "", $action = "")
    {
        if (is_null(Auth::user())) {
            return false;
        }
        $redis = Redis::get(config('constants.REDIS_ACCESS').Auth::user()->id);
        $user = json_decode($redis, true);
        $action = Action::select('action_id')->where('action_name', $action)->first();
        if (is_null($action)) {
            return false;
        }
        $roleAction = RoleMenuAction::where('action_id', $action->action_id)
            ->where('menu_id', $menuId)
            ->where('roles_id', $user['role']['role_id'])
            ->first();
        if (is_null($roleAction)) {
            return false;
        }
        return true;
    }

    public static function checkRole($param = "")
    {
        if (is_null(Auth::user())) {
            return [
                'menu_id' => "",
                'status' => false
            ];
        }
        $menuId = "";
        $isRole = false;
        $redis = Redis::get(config('constants.REDIS_ACCESS').Auth::user()->id);
        $user = json_decode($redis, true);
        $menus = $user['role']['menu'];
        $role = array_search($param, array_column($menus, 'menu_url'));
        if (is_bool($role) != true) {
            $isRole = true;
            $menuId = $menus[$role]['menu_id'];
        }
        foreach($menus as $key => $menu) {
            if (!empty($menu['sub_menu'])) {
                $subMenu = array_search($param, array_column($menu['sub_menu'], 'menu_url'));
                if (!is_bool($subMenu)) {
                    $isRole = true;
                    $menuId = $menu['sub_menu'][$subMenu]['menu_id'];
                    break;
                }
            }
        };
        return [
            'menu_id' => $menuId,
            'status' => $isRole
        ];
    }

    public static function sendMail($param, $template)
    {
        try {
            Mail::send($template, $param, function ($mail) use ($param) {
                $mail->from(config('constants.FROM_MAIL'), config('constants.FROM_NAME'));
                $mail->to($param['to_mail'], $param['to_name']);
                $mail->subject($param['subject']);
                if (isset($param['bcc']))
                {
                    $mail->bcc($param['bcc']);
                }
            });
            info("SUCCESS EMAIL");
        } catch (\Throwable $th) {
            info("ERROR EMAIL ". $th->getMessage());
        }
    }
}