<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    protected $table = 'transaction';
    protected $primaryKey = 'transaction_id';

    public function doctor()
    {
        return $this->hasOne('App\Doctor', 'doctor_id', 'doctor_id');
    }

    public function pasien()
    {
        return $this->belongsTo('App\Pasien', 'pasien_id', 'pasien_id');
    }

    public function status()
    {
        return $this->belongsTo('App\Status', 'transaction_status', 'status_id');
    }
}
