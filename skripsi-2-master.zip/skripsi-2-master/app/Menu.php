<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
    protected $table = 'menu';

    public function subMenu()
    {
        return $this->hasMany('App\SubMenu', 'menu_id', 'menu_id');
    }

    public function scopeActive($query)
    {
        return $query->where('menu_status', 1);
    }
}
