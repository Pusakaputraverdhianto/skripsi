<?php

return [
    'REDIS_ACCESS' => 'user_access_skripsi_2_',
    'IMAGE_PATH' => '/Users/arak/Documents/MY DOCS/WEB/TA/skripsi-2/public/images/',
    'FROM_MAIL' => 'untukamal@gmail.com',
    'FROM_NAME' => 'Untuk Amal'
];
