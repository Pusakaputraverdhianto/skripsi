<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'Auth\LoginController@index');
Route::get('login', 'Auth\LoginController@login')->name('login');
Route::post('doLogin', 'Auth\LoginController@doLogin')->name('doLogin');
Route::get('logout', 'Auth\LoginController@logout')->name('logout');
Route::post('forgot-password', 'Auth\LoginController@forgotPassword')->name('forgot-password');
Route::get('register', 'Auth\LoginController@register');
Route::get('do-register', 'Auth\LoginController@doRegister')->name('doRegister');
Route::get('home', 'HomeController@index')->name('home');

// USER
Route::get('user/edit/{id}', 'UserController@edit');
Route::get('user/delete/{id}', 'UserController@destroy');
Route::get('user', 'UserController@index')->name('user');
Route::get('add-user', 'UserController@create');
Route::resource('user', 'UserController');

// ROLE
Route::get('role/edit/{id}', 'RoleController@edit');
Route::get('role/delete/{id}', 'RoleController@destroy');
Route::get('role', 'RoleController@index')->name('role');
Route::get('add-role', 'RoleController@create');
Route::get('role/access/{id}', 'RoleController@access');
Route::get('role/action/{id}', 'RoleController@action');
Route::post('addAccess', 'RoleController@addAccess')->name('addAccess');
Route::post('addAction', 'RoleController@addAction')->name('addAction');
Route::resource('role', 'RoleController');

// POLI
Route::get('poli/edit/{id}', 'PoliController@edit');
Route::get('poli/delete/{id}', 'PoliController@destroy');
Route::get('poli', 'PoliController@index')->name('poli');
Route::get('add-poli', 'PoliController@create');
Route::resource('poli', 'PoliController');

// DOCTOR
Route::get('doctor/edit/{id}', 'DoctorControllerr@edit');
Route::get('doctor/delete/{id}', 'DoctorControllerr@destroy');
Route::get('doctor', 'DoctorControllerr@index')->name('doctor');
Route::get('add-doctor', 'DoctorControllerr@create');
Route::resource('doctor', 'DoctorControllerr');

// TIME
Route::get('time/list/{id}', 'TimeController@index');
Route::get('time/edit/{id}', 'TimeController@edit');
Route::get('time/delete/{id}', 'TimeController@destroy');
Route::get('time/create/{id}', 'TimeController@create');
Route::resource('time', 'TimeController');

Route::get('schedule/generate', 'ScheduleController@generateSchedule');
Route::get('schedule/list/{id}', 'ScheduleController@index');
Route::post('updateSchedule', 'ScheduleController@updateSchedule')->name('updateSchedule');

// FRONTEND
Route::get('search', 'SearchController@index');
Route::post('search/check-avail', 'SearchController@checkAvail');
Route::get('search/avail', 'SearchController@avail');
Route::get('search/detail', 'SearchController@detail');
Route::get('search/data-pasien', 'SearchController@dataPasien');
Route::post('do-search', 'SearchController@doSearch')->name('do-search');
Route::post('reservation', 'SearchController@reservation')->name('reservation');
Route::get('transaction/{param}', 'SearchController@transaction');
Route::post('transaction/history', 'SearchController@transactionHistory')->name('transactionHistory');
Route::get('search/reservation', 'SearchController@reservationCheck');

// Pasien
Route::get('pasien', 'PasienController@index');
Route::post('check/data-pasien', 'PasienController@checkDataPasien');
Route::get('list/transaction', 'TransactionController@index');
Route::get('update/jadwal/reservasi', 'TransactionController@updateJadwalReservasi');
Route::resource('update_jadwal_reservasi', 'TransactionController');
Route::post('change/transaction/status', 'TransactionController@changeStatus');